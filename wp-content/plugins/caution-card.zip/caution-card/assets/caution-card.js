(function () {
  "use strict";

  // Inject spinner keyframe animation once
  var spinnerStyle = document.createElement("style");
  spinnerStyle.textContent = [
    "@keyframes pcpx-spin { 0%{transform:rotate(0deg)} 100%{transform:rotate(360deg)} }",
    "@keyframes pcpx-fade-in { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }",
  ].join("\n");
  document.head.appendChild(spinnerStyle);

  function isValidUrl(href) {
    if (!href) return false;
    var trimmed = href.trim();
    if (!trimmed || trimmed === "#" || trimmed === "" || trimmed.indexOf("javascript") === 0) return false;
    try {
      var url = new URL(trimmed, window.location.origin);
      return url.protocol === "http:" || url.protocol === "https:";
    } catch (e) {
      return false;
    }
  }

  function createSpinner() {
    var overlay = document.createElement("div");
    overlay.setAttribute("id", "pcpx-spinner-overlay");
    overlay.style.cssText = [
      "width:1200px",
      "max-width:95%",
      "min-height:300px",
      "display:flex",
      "flex-direction:column",
      "align-items:center",
      "justify-content:center",
      "background:#ffffff",
      "border-radius:16px",
      "border:4px solid #e5e7eb",
      "box-shadow:0 15px 40px rgba(0,0,0,0.12)",
      "margin:40px auto",
      "gap:24px",
      "z-index:99999",
      "position:relative",
      "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif",
    ].join(";");

    var ring = document.createElement("div");
    ring.style.cssText = [
      "width:60px",
      "height:60px",
      "border:6px solid #f3f4f6",
      "border-top-color:#16a34a",
      "border-radius:50%",
      "animation:pcpx-spin 1s linear infinite",
    ].join(";");

    var label = document.createElement("p");
    label.style.cssText = "margin:0;font-size:18px;font-weight:700;color:#111827;letter-spacing:0.5px;";
    label.textContent = "Verifying Product Authenticity…";

    var sublabel = document.createElement("p");
    sublabel.style.cssText = "margin:-10px 0 0 0;font-size:14px;color:#6b7280;";
    sublabel.textContent = "Please wait while we check for discontinued status.";

    overlay.appendChild(ring);
    overlay.appendChild(label);
    overlay.appendChild(sublabel);
    return overlay;
  }

  function handleClick(event) {
    // Look for ANY button/link that might be a CTA
    var hit = event.target.closest("a, button");
    if (!hit) return;

    // Check if it's a product card button
    var isProductCardBtn = hit.classList.contains("pcpx-cta-button") || 
                           hit.closest(".pcpx-product-card-outer") ||
                           hit.closest(".product-card");
    
    if (!isProductCardBtn) return;

    var href = hit.getAttribute("href") || "";
    
    // If URL is valid, let it through
    if (isValidUrl(href)) return;

    console.log("Caution Card: Invalid URL detected on CTA. Triggering loader...");
    event.preventDefault();
    event.stopPropagation();

    // Prevent double triggers
    if (document.getElementById("pcpx-spinner-overlay")) return;

    var card = document.querySelector(".pcpx-caution-card-outer");
    if (!card) {
      console.error("Caution Card: Could not find card element on page.");
      return;
    }

    var container = hit.closest(".pcpx-product-card-outer") || hit.closest(".product-card");
    var spinner = createSpinner();

    if (container) {
      container.parentNode.insertBefore(spinner, container.nextSibling);
      container.style.display = "none";
    } else {
      card.parentNode.insertBefore(spinner, card);
    }

    // Scroll to spinner
    spinner.scrollIntoView({ behavior: 'smooth', block: 'center' });

    setTimeout(function () {
      var activeSpinner = document.getElementById("pcpx-spinner-overlay");
      if (activeSpinner && activeSpinner.parentNode) {
        activeSpinner.parentNode.removeChild(activeSpinner);
      }

      if (container && card.parentNode !== container.parentNode) {
        container.parentNode.insertBefore(card, container.nextSibling);
      }

      card.style.display = "block";
      card.style.opacity = "0";
      card.style.visibility = "visible";
      card.style.animation = "pcpx-fade-in 0.8s ease forwards";

      requestAnimationFrame(function () {
        requestAnimationFrame(function () {
          card.style.transition = "opacity 0.8s ease";
          card.style.opacity = "1";
        });
      });
    }, 5000);
  }

  document.addEventListener("DOMContentLoaded", function () {
    console.log("Caution Card: JS Ready.");
    
    // Ensure all cards are hidden initially
    document.querySelectorAll(".pcpx-caution-card-outer").forEach(function (card) {
      card.style.display = "none";
    });

    // Catch clicks on document level
    document.addEventListener("click", handleClick, true);
  });
})();
