(function (wp) {
  const { registerBlockType } = wp.blocks;
  const { InspectorControls, useBlockProps } = wp.blockEditor;
  const { PanelBody, TextControl, Placeholder } = wp.components;
  const { createElement: el, Fragment } = wp.element;

  registerBlockType("caution-card/block", {
    edit: function (props) {
      const { attributes, setAttributes } = props;
      const blockProps = useBlockProps({
        className: "pcpx-caution-block-editor",
        style: {
          border: "2px solid #ef0000",
          borderRadius: "12px",
          padding: "20px",
          background: "#fff9f9",
          cursor: "pointer",
          minHeight: "100px",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justify-content: "center",
          textAlign: "center"
        }
      });

      return el(
        Fragment,
        null,
        el(
          InspectorControls,
          null,
          el(
            PanelBody,
            { title: "Caution Card Settings", initialOpen: true },
            el(TextControl, {
              label: "New Product Name",
              value: attributes.newProductName,
              onChange: (value) => setAttributes({ newProductName: value })
            }),
            el(TextControl, {
              label: "New Product Image URL",
              value: attributes.newProductImageUrl,
              onChange: (value) => setAttributes({ newProductImageUrl: value })
            }),
            el(TextControl, {
              label: "Feature 1",
              value: attributes.feature1,
              onChange: (value) => setAttributes({ feature1: value })
            }),
            el(TextControl, {
              label: "Feature 2",
              value: attributes.feature2,
              onChange: (value) => setAttributes({ feature2: value })
            }),
            el(TextControl, {
              label: "Feature 3",
              value: attributes.feature3,
              onChange: (value) => setAttributes({ feature3: value })
            }),
            el(TextControl, {
              label: "Read More URL",
              value: attributes.readMoreUrl,
              onChange: (value) => setAttributes({ readMoreUrl: value })
            })
          )
        ),
        el(
          "div",
          blockProps,
          el("div", { style: { fontSize: "32px", marginBottom: "10px" } }, "⚠️"),
          el("h3", { style: { margin: 0, color: "#ef0000", fontSize: "18px" } }, "Caution Card Block"),
          el("p", { style: { margin: "10px 0 0 0", color: "#666", fontSize: "14px" } }, 
            attributes.newProductName ? "Replacement: " + attributes.newProductName : "Click to configure discontinued product replacement in the sidebar."
          )
        )
      );
    },
    save: function () {
      return null;
    }
  });
})(window.wp);
