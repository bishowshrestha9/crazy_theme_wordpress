<?php
/**
 * Plugin Name: Caution Card
 * Description: Gutenberg Caution Card block for discontinued products with ACF integration.
 * Version: 1.1.0
 * Author: Your Name
 * Text Domain: caution-card
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Caution_Card_Plugin {
	const OPTION_KEY = 'caution_card_settings';
	const PAGE_SLUG = 'caution-card';

	public static function init() {
		$instance = new self();
		$instance->hooks();
	}

	public static function activate() {
		$instance = new self();
		$instance->create_page_if_missing();
		$instance->ensure_default_options();
	}

	private function hooks() {
		add_action( 'admin_menu', array( $this, 'register_admin_page' ) );
		add_action( 'admin_post_caution_card_save', array( $this, 'save_settings' ) );
		add_shortcode( 'caution_card', array( $this, 'render_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'init', array( $this, 'register_block' ) );
	}

	private function ensure_default_options() {
		$defaults = array(
			'new_product_name' => '',
			'new_product_image' => '',
			'feature_1' => '',
			'feature_2' => '',
			'feature_3' => '',
			'rating_value' => '4.9',
			'review_count' => '12598',
			'rating_stars' => '5',
			'read_more_url' => '',
			'contact_url' => '',
			'show_alternatives_link' => '',
		);

		$current = get_option( self::OPTION_KEY );
		if ( ! is_array( $current ) ) {
			update_option( self::OPTION_KEY, $defaults );
		}
	}

	private function create_page_if_missing() {
		$page = get_page_by_path( self::PAGE_SLUG );
		if ( $page ) {
			return;
		}

		$page_id = wp_insert_post(
			array(
				'post_title' => 'Caution Card',
				'post_name' => self::PAGE_SLUG,
				'post_status' => 'publish',
				'post_type' => 'page',
				'post_content' => '[caution_card]',
			)
		);

		if ( $page_id && ! is_wp_error( $page_id ) ) {
			update_option( 'caution_card_page_id', (int) $page_id );
		}
	}

	public function register_admin_page() {
		add_options_page(
			__( 'Caution Card', 'caution-card' ),
			__( 'Caution Card', 'caution-card' ),
			'manage_options',
			'caution-card',
			array( $this, 'render_admin_page' )
		);
	}

	public function render_admin_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$options = $this->get_settings();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Caution Card Settings', 'caution-card' ); ?></h1>
			<p><?php esc_html_e( 'Fill out the fields below. The card will render on /caution-card.', 'caution-card' ); ?></p>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="caution_card_save">
				<?php wp_nonce_field( 'caution_card_save', 'caution_card_nonce' ); ?>

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="new_product_name"><?php esc_html_e( 'New Product Name', 'caution-card' ); ?></label></th>
						<td><input type="text" class="regular-text" id="new_product_name" name="new_product_name" value="<?php echo esc_attr( $options['new_product_name'] ); ?>"></td>
					</tr>
					<tr>
						<th scope="row"><label for="new_product_image"><?php esc_html_e( 'New Product Image URL', 'caution-card' ); ?></label></th>
						<td><input type="url" class="regular-text" id="new_product_image" name="new_product_image" value="<?php echo esc_attr( $options['new_product_image'] ); ?>"></td>
					</tr>
					<tr>
						<th scope="row"><label for="feature_1"><?php esc_html_e( 'Feature Bullet 1', 'caution-card' ); ?></label></th>
						<td><input type="text" class="regular-text" id="feature_1" name="feature_1" value="<?php echo esc_attr( $options['feature_1'] ); ?>"></td>
					</tr>
					<tr>
						<th scope="row"><label for="feature_2"><?php esc_html_e( 'Feature Bullet 2', 'caution-card' ); ?></label></th>
						<td><input type="text" class="regular-text" id="feature_2" name="feature_2" value="<?php echo esc_attr( $options['feature_2'] ); ?>"></td>
					</tr>
					<tr>
						<th scope="row"><label for="feature_3"><?php esc_html_e( 'Feature Bullet 3', 'caution-card' ); ?></label></th>
						<td><input type="text" class="regular-text" id="feature_3" name="feature_3" value="<?php echo esc_attr( $options['feature_3'] ); ?>"></td>
					</tr>
					<tr>
						<th scope="row"><label for="rating_value"><?php esc_html_e( 'Rating Value', 'caution-card' ); ?></label></th>
						<td><input type="text" class="regular-text" id="rating_value" name="rating_value" value="<?php echo esc_attr( $options['rating_value'] ); ?>"></td>
					</tr>
					<tr>
						<th scope="row"><label for="review_count"><?php esc_html_e( 'Review Count', 'caution-card' ); ?></label></th>
						<td><input type="number" class="regular-text" id="review_count" name="review_count" value="<?php echo esc_attr( $options['review_count'] ); ?>"></td>
					</tr>
					<tr>
						<th scope="row"><label for="rating_stars"><?php esc_html_e( 'Rating Stars (1-5)', 'caution-card' ); ?></label></th>
						<td><input type="number" min="1" max="5" class="regular-text" id="rating_stars" name="rating_stars" value="<?php echo esc_attr( $options['rating_stars'] ); ?>"></td>
					</tr>
					<tr>
						<th scope="row"><label for="read_more_url"><?php esc_html_e( 'Read More URL', 'caution-card' ); ?></label></th>
						<td><input type="url" class="regular-text" id="read_more_url" name="read_more_url" value="<?php echo esc_attr( $options['read_more_url'] ); ?>"></td>
					</tr>
					<tr>
						<th scope="row"><label for="show_alternatives_link"><?php esc_html_e( 'Look Other Alternative URL', 'caution-card' ); ?></label></th>
						<td><input type="url" class="regular-text" id="show_alternatives_link" name="show_alternatives_link" value="<?php echo esc_attr( $options['show_alternatives_link'] ); ?>"></td>
					</tr>
					<tr>
						<th scope="row"><label for="contact_url"><?php esc_html_e( 'Contact URL', 'caution-card' ); ?></label></th>
						<td><input type="url" class="regular-text" id="contact_url" name="contact_url" value="<?php echo esc_attr( $options['contact_url'] ); ?>"></td>
					</tr>
				</table>

				<p class="submit">
					<button type="submit" class="button button-primary"><?php esc_html_e( 'Save Settings', 'caution-card' ); ?></button>
				</p>
			</form>
		</div>
		<?php
	}

	public function save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized', 'caution-card' ), 403 );
		}

		check_admin_referer( 'caution_card_save', 'caution_card_nonce' );

		$settings = array(
			'new_product_name' => sanitize_text_field( wp_unslash( $_POST['new_product_name'] ?? '' ) ),
			'new_product_image' => esc_url_raw( wp_unslash( $_POST['new_product_image'] ?? '' ) ),
			'feature_1' => sanitize_text_field( wp_unslash( $_POST['feature_1'] ?? '' ) ),
			'feature_2' => sanitize_text_field( wp_unslash( $_POST['feature_2'] ?? '' ) ),
			'feature_3' => sanitize_text_field( wp_unslash( $_POST['feature_3'] ?? '' ) ),
			'rating_value' => sanitize_text_field( wp_unslash( $_POST['rating_value'] ?? '' ) ),
			'review_count' => sanitize_text_field( wp_unslash( $_POST['review_count'] ?? '' ) ),
			'rating_stars' => sanitize_text_field( wp_unslash( $_POST['rating_stars'] ?? '' ) ),
			'read_more_url' => esc_url_raw( wp_unslash( $_POST['read_more_url'] ?? '' ) ),
			'contact_url' => esc_url_raw( wp_unslash( $_POST['contact_url'] ?? '' ) ),
			'show_alternatives_link' => esc_url_raw( wp_unslash( $_POST['show_alternatives_link'] ?? '' ) ),
		);

		update_option( self::OPTION_KEY, $settings );

		wp_redirect( add_query_arg( array( 'page' => 'caution-card', 'updated' => 'true' ), admin_url( 'options-general.php' ) ) );
		exit;
	}

	private function get_settings() {
		$options = get_option( self::OPTION_KEY, array() );
		return wp_parse_args(
			$options,
			array(
				'new_product_name' => '',
				'new_product_image' => '',
				'feature_1' => '',
				'feature_2' => '',
				'feature_3' => '',
				'rating_value' => '4.9',
				'review_count' => '12598',
				'rating_stars' => '5',
				'read_more_url' => '',
				'contact_url' => '',
				'show_alternatives_link' => '',
			)
		);
	}

	public function enqueue_assets() {
		// Always enqueue if on a single page, to ensure the card works if triggered
		if ( ! is_singular() ) {
			return;
		}

		wp_enqueue_style(
			'caution-card-style',
			plugin_dir_url( __FILE__ ) . 'assets/caution-card.css',
			array(),
			'1.2.0'
		);

		wp_enqueue_script(
			'caution-card-script',
			plugin_dir_url( __FILE__ ) . 'assets/caution-card.js',
			array(),
			'1.2.0',
			true
		);
	}

	public function register_block() {
		wp_register_style(
			'caution-card-style',
			plugin_dir_url( __FILE__ ) . 'assets/caution-card.css',
			array(),
			'1.2.0'
		);

		wp_register_script(
			'caution-card-block',
			plugin_dir_url( __FILE__ ) . 'blocks/caution-card/editor.js',
			array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components' ),
			'1.2.0',
			true
		);

		register_block_type(
			plugin_dir_path( __FILE__ ) . 'blocks/caution-card',
			array(
				'render_callback' => array( $this, 'render_block' ),
			)
		);
	}

	public function render_shortcode() {
		return $this->render_card_markup( array(), true );
	}

	public function render_block( $attributes ) {
		return $this->render_card_markup( (array) $attributes, false );
	}

	private function render_card_markup( $attributes, $use_settings_fallback ) {
		$settings = $this->get_settings();

		$acf_product_name = '';
		if ( function_exists( 'get_field' ) ) {
			$acf_product_name = get_field( 'product_name' );
		}

		$old_product_name = $acf_product_name ? $acf_product_name : __( 'this product', 'caution-card' );

		$new_product_name = $this->pick_value( $attributes, 'newProductName', $use_settings_fallback ? $settings['new_product_name'] : '' );
		$new_product_name = $new_product_name ? $new_product_name : __( 'New Product', 'caution-card' );

		$new_product_image = $this->pick_value( $attributes, 'newProductImageUrl', '' );
		if ( ! $new_product_image ) {
			$new_product_image = $this->pick_value( $attributes, 'newProductImage', $use_settings_fallback ? $settings['new_product_image'] : '' );
		}

		$feature_1 = $this->pick_value( $attributes, 'feature1', $use_settings_fallback ? $settings['feature_1'] : '' );
		$feature_2 = $this->pick_value( $attributes, 'feature2', $use_settings_fallback ? $settings['feature_2'] : '' );
		$feature_3 = $this->pick_value( $attributes, 'feature3', $use_settings_fallback ? $settings['feature_3'] : '' );

		$feature_1 = $feature_1 ? $feature_1 : __( 'Designed for harder erection, higher stamina, more libido', 'caution-card' );
		$feature_2 = $feature_2 ? $feature_2 : __( 'All Natural Ingredients with No Side Effects', 'caution-card' );
		$feature_3 = $feature_3 ? $feature_3 : __( '98% effective and results within 4 Weeks', 'caution-card' );

		$read_more_url = $this->pick_value( $attributes, 'readMoreUrl', $settings['read_more_url'] );
		$read_more_url = $read_more_url ? $read_more_url : '#';

		$contact_url = $this->pick_value( $attributes, 'contactUrl', $settings['contact_url'] );
		$contact_url = $contact_url ? $contact_url : '#';

		$alternatives_url = $this->pick_value( $attributes, 'alternativesUrl', $settings['show_alternatives_link'] );
		$alternatives_url = $alternatives_url ? $alternatives_url : '#';
		$trigger_selector = $this->pick_value( $attributes, 'triggerSelector', '.pcpx-cta-button' );
		$container_selector = $this->pick_value( $attributes, 'containerSelector', '.pcpx-product-card-outer' );

		$recommendation_text = sprintf(
			'We recommend <span class="pcpx-caution-highlight">%s</span> as the safer, more reliable alternative to <span class="pcpx-caution-highlight pcpx-caution-highlight--danger">%s</span>.',
			esc_html( $new_product_name ),
			esc_html( $old_product_name )
		);

		$rating_value = $this->pick_value( $attributes, 'ratingValue', $settings['rating_value'] );
		$review_count = $this->pick_value( $attributes, 'reviewCount', $settings['review_count'] );

		ob_start();

		// SVG icons as PHP variables from assets/icons
		$svg_check = '<svg width="20" height="20" viewBox="0 0 24 24" role="img" aria-label="Check" style="display:inline-block;vertical-align:middle;flex-shrink:0"><defs><radialGradient id="checkGrad" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#f4fff8"/><stop offset="1" stop-color="#d9f7e5"/></radialGradient></defs><circle cx="12" cy="12" r="10.5" fill="url(#checkGrad)" stroke="#9dd9b5" stroke-width="1.5"/><path d="M9.3 15.9 6 12.6a1 1 0 0 1 1.4-1.4l2.2 2.2 6-6a1 1 0 1 1 1.4 1.4l-6.7 6.7a1 1 0 0 1-1.4 0Z" fill="#159447"/></svg>';
		
		$svg_warning = '<svg width="22" height="22" viewBox="0 0 32 32" role="img" aria-label="Warning" style="display:inline-block;vertical-align:middle;flex-shrink:0"><circle cx="16" cy="16" r="14.5" fill="#ffffff" stroke="#ef4444" stroke-width="2"/><path d="M16 6.2 5.4 24.5h21.2L16 6.2Zm0 5.4c.9 0 1.6.7 1.6 1.6v5.5c0 .9-.7 1.6-1.6 1.6s-1.6-.7-1.6-1.6v-5.5c0-.9.7-1.6 1.6-1.6Zm0 11a1.9 1.9 0 1 1 0-3.8 1.9 1.9 0 0 1 0 3.8Z" fill="#ef4444"/></svg>';
		
		$svg_shield = '<svg width="20" height="20" viewBox="0 0 28 28" role="img" aria-label="Certified" style="display:inline-block;vertical-align:middle;flex-shrink:0"><circle cx="14" cy="14" r="13" fill="#ecfdf3" stroke="#86efac" stroke-width="1.5"/><path d="M14 6.1 8.2 8.5v5.8c0 3.9 2.4 7.3 5.8 8.6 3.4-1.3 5.8-4.7 5.8-8.6V8.5L14 6.1Zm-1.4 10.7-2.3-2.3a1 1 0 0 1 1.4-1.4l1.6 1.6 3.2-3.2a1 1 0 1 1 1.4 1.4l-3.9 3.9a1 1 0 0 1-1.4 0Z" fill="#16a34a"/></svg>';
		
		$svg_seal = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="96" height="96" style="display:block;filter:drop-shadow(0 4px 8px rgba(0,0,0,0.25));" role="img" aria-label="Top Rated"><defs><radialGradient id="goldGrad" cx="35%" cy="30%" r="80%"><stop offset="0" stop-color="#fff3b0"/><stop offset="0.55" stop-color="#f4c430"/><stop offset="1" stop-color="#d39e00"/></radialGradient></defs><circle cx="60" cy="60" r="54" fill="url(#goldGrad)"/><circle cx="60" cy="60" r="48" fill="none" stroke="#ffffff" stroke-opacity="0.7" stroke-width="3"/><circle cx="60" cy="60" r="40" fill="none" stroke="#fff4bf" stroke-width="3" stroke-dasharray="4 4"/><g fill="#ffffff" font-family="Arial, sans-serif" font-weight="700" text-anchor="middle"><text x="60" y="46" font-size="12">★★★★★</text><text x="60" y="66" font-size="18">TOP RATED</text><text x="60" y="84" font-size="9">QUALITY VERIFIED</text></g></svg>';

		?>
		<style>
		@media (max-width:780px) {
			.pcpx-c-body { flex-direction:column !important; }
			.pcpx-c-right { flex:none !important; width:100% !important; order:-1; margin-bottom:20px; }
			.pcpx-c-left { flex:none !important; width:100% !important; }
			.pcpx-c-cta-row { flex-direction:column !important; align-items:stretch !important; }
			.pcpx-c-cta-row a:first-child { text-align:center !important; justify-content:center !important; display:flex !important; }
			.pcpx-c-footer { flex-direction:column !important; gap:8px !important; text-align:center !important; }
		}
		</style>
		<div class="pcpx-caution-card-outer" data-trigger-selector="<?php echo esc_attr( $trigger_selector ); ?>" data-container-selector="<?php echo esc_attr( $container_selector ); ?>" style="display:none;max-width:1200px;width:100%;margin:40px auto;padding:0 20px;box-sizing:border-box;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;">
			<div style="background:#ffffff;border-radius:16px;box-shadow:0 4px 16px rgba(0,0,0,0.08),0 2px 6px rgba(0,0,0,0.04);overflow:visible;border:4px solid #e5e7eb;position:relative;">

				<!-- 1. Red Warning Header -->
				<div style="background:#ef0000;display:flex;align-items:center;gap:12px;padding:14px 28px;">
					<?php echo $svg_warning; // phpcs:ignore ?>
					<p style="margin:0;padding:0;color:#fff;font-size:15px;font-weight:700;line-height:1.4;">
						<strong style="font-weight:800;">Caution:</strong>
						<?php echo esc_html( sprintf( ' Due to quality-control and counterfeit concerns, %s has been discontinued.', $old_product_name ) ); ?>
					</p>
				</div>

				<!-- 2. Main 2-Column Body -->
				<div class="pcpx-c-body" style="display:flex;flex-direction:row;align-items:center;padding:36px 32px 28px;gap:32px;">

					<!-- LEFT: Text Content -->
					<div class="pcpx-c-left" style="flex:1;min-width:0;">

						<h2 style="margin:0 0 20px 0;padding:0;font-size:28px;line-height:1.25;font-weight:800;color:#111827;">
							We recommend <span style="color:#16a34a;"><?php echo esc_html( $new_product_name ); ?></span> as the safer, more reliable alternative to <span style="color:#ef4444;"><?php echo esc_html( $old_product_name ); ?></span>
						</h2>

						<!-- Checklist -->
						<ul style="list-style:none;margin:0 0 20px 0;padding:0;">
							<li style="display:flex;align-items:center;gap:10px;margin-bottom:10px;font-size:16px;color:#374151;">
								<?php echo $svg_check; // phpcs:ignore ?>
								<span><?php echo esc_html( $feature_1 ); ?></span>
							</li>
							<li style="display:flex;align-items:center;gap:10px;margin-bottom:10px;font-size:16px;color:#374151;">
								<?php echo $svg_check; // phpcs:ignore ?>
								<span><?php echo esc_html( $feature_2 ); ?></span>
							</li>
							<li style="display:flex;align-items:center;gap:10px;font-size:16px;color:#374151;">
								<?php echo $svg_check; // phpcs:ignore ?>
								<span><?php echo esc_html( $feature_3 ); ?></span>
							</li>
						</ul>

						<!-- Badges: FDA & GMP -->
						<div style="display:flex;gap:24px;margin-bottom:24px;flex-wrap:wrap;">
							<div style="display:flex;align-items:center;gap:8px;font-size:14px;font-weight:700;color:#111827;">
								<?php echo $svg_shield; // phpcs:ignore ?>
								<span>FDA Approved</span>
							</div>
							<div style="display:flex;align-items:center;gap:8px;font-size:14px;font-weight:700;color:#111827;">
								<?php echo $svg_shield; // phpcs:ignore ?>
								<span>GMP Certified</span>
							</div>
						</div>

						<!-- CTA Row -->
						<div class="pcpx-c-cta-row" style="display:flex;align-items:center;gap:20px;margin-bottom:24px;flex-wrap:wrap;">
							<?php if ( ! empty( $read_more_url ) ) : ?>
								<a href="<?php echo esc_url( $read_more_url ); ?>" target="_blank" rel="noopener"
								   style="display:inline-flex;align-items:center;gap:8px;background:#2e7d0d;color:#fff;text-decoration:none;padding:14px 28px;border-radius:8px;font-size:17px;font-weight:800;white-space:nowrap;">
									Read More about <?php echo esc_html( $new_product_name ); ?> <span style="font-size:18px;">→</span>
								</a>
							<?php endif; ?>
							<?php if ( ! empty( $alternatives_url ) ) : ?>
								<a href="<?php echo esc_url( $alternatives_url ); ?>" target="_blank" rel="noopener"
								   style="color:#111827;text-decoration:underline;font-size:16px;font-weight:700;white-space:nowrap;">
									Look Other Alternative
								</a>
							<?php endif; ?>
						</div>

						<!-- Social Proof -->
						<div style="display:flex;align-items:center;gap:12px;">
							<div style="display:flex;">
								<img src="https://i.pravatar.cc/100?u=r1" width="30" height="30" style="border-radius:50%;border:2px solid #fff;margin-left:0;display:block;" alt="">
								<img src="https://i.pravatar.cc/100?u=r2" width="30" height="30" style="border-radius:50%;border:2px solid #fff;margin-left:-8px;display:block;" alt="">
								<img src="https://i.pravatar.cc/100?u=r3" width="30" height="30" style="border-radius:50%;border:2px solid #fff;margin-left:-8px;display:block;" alt="">
							</div>
							<div>
								<div style="color:#f59e0b;font-size:16px;line-height:1;">★★★★★</div>
								<div style="font-size:13px;color:#6b7280;margin-top:2px;">
									<strong style="color:#111827;"><?php echo esc_html( $rating_value ); ?>/5</strong>
									<?php echo esc_html( $review_count ); ?>+ user reviews
								</div>
							</div>
						</div>

					</div><!-- /LEFT -->

					<!-- RIGHT: Product Image + Gold Seal -->
					<div class="pcpx-c-right" style="flex:0 0 320px;position:relative;display:flex;align-items:center;justify-content:center;">
						<?php if ( ! empty( $new_product_image ) ) : ?>
							<img src="<?php echo esc_url( $new_product_image ); ?>"
							     alt="<?php echo esc_attr( $new_product_name ); ?>"
							     style="max-width:100%;height:auto;display:block;max-height:340px;object-fit:contain;">
						<?php endif; ?>

						<!-- Gold Seal Badge (SVG Star-burst) -->
						<div style="position:absolute;top:-18px;right:-18px;width:90px;height:90px;">
							<?php echo $svg_seal; // phpcs:ignore ?>
						</div>
					</div><!-- /RIGHT -->

				</div><!-- /2-col body -->

				<!-- 4. Footer -->
				<div class="pcpx-c-footer" style="border-top:1px solid #f3f4f6;padding:16px 32px;display:flex;justify-content:space-between;align-items:center;background:#fafafa;">
					<p style="margin:0;font-size:12px;color:#9ca3af;">Our recommendation is based on formula quality, consistency, and availability.</p>
					<?php if ( ! empty( $contact_url ) ) : ?>
						<p style="margin:0;font-size:12px;color:#6b7280;">
							Owner of <?php echo esc_html( $new_product_name ); ?>? <a href="<?php echo esc_url( $contact_url ); ?>" target="_blank" rel="noopener" style="color:#374151;text-decoration:underline;">Contact Us</a>
						</p>
					<?php endif; ?>
				</div>

			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	private function pick_value( $attributes, $key, $fallback ) {
		if ( isset( $attributes[ $key ] ) && '' !== $attributes[ $key ] && null !== $attributes[ $key ] ) {
			return $attributes[ $key ];
		}

		return $fallback;
	}
}

register_activation_hook( __FILE__, array( 'Caution_Card_Plugin', 'activate' ) );
add_action( 'plugins_loaded', array( 'Caution_Card_Plugin', 'init' ) );
